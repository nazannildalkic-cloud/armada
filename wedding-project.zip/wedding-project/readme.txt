Achtung: Voice Agent funktioniert nur online (Github Pages) oder via lokalen Server. Doppelklick blockiert oft das Mikrofon.
